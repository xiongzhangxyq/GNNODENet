# GNNODENet
GNN-ODENet epidemic forecasting
